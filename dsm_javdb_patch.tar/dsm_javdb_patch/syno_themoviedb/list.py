#!/usr/bin/python2
#-*- coding:utf8 -*-
# By sanyle 2018-05-03

import requests
import re,sys,json,os
from bs4 import BeautifulSoup
import getcookie

reload(sys)
sys.setdefaultencoding('utf8')

headers={"User-Agent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko)",
         "Accept": "text/html,application/xhtml+xml,application/xml",
         "Accept-Language": "zh-CN,zh;q=0.9",
         "Upgrade-Insecure-Requests":"1",
         "Referer": "https://www.douban.com/"
         }

def baiduformatTi(title):
    url = "http://www.baidu.com/s?ie=utf-8&wd={}&pn={}"
    rt = ""
    gtitle = title
    for pn in range(3):
        r = requests.get(url.format(gtitle, pn*10), headers=headers)
        if r.status_code != 200:
            continue
        r = r.content.decode("utf-8")
        soup = BeautifulSoup(r, "lxml")
        try:
            gtitle = soup.select('.c-gap-bottom-small > span > strong')[1].text
        except:
            pass
        conlist = soup.select("#content_left > div")
        for i in conlist:
            try:
                ti = i.select("h3")[0].text.strip()
            except:
                continue
            try:
                ft = ti.split("》")[0].split("《")[1]
                if ft in gtitle:
                    rt = ft
                    break
            except:
                pass
            try:
                ft = re.split(r"\_|\-|\ ", ti)[0]
                if ft in gtitle:
                    rt = ft
                    break
            except:
                pass
        if rt:
            break
    if rt:
        return rt
    else:
        return gtitle

def doubanlist(title):
    ck = getcookie.get(True)
    cookies = dict(bid=ck['bid'],ll=ck['ll'])
    url = "https://www.douban.com/search?cat=1002&q="
    r = requests.get(url+title,headers=headers,cookies=cookies)
    if r.status_code == 403:
        os.remove('/var/packages/VideoStation/target/plugins/syno_themoviedb/dbcook.txt')
        return 'reget'
    r = r.content.decode("utf-8")
    soup = BeautifulSoup(r,"lxml")
    list = soup.select(".search-result > .result-list > .result")
    json = {}
    listnum = len(list)
    json['total'] = listnum
    if listnum == 0:
        return json
    data = []
    same = False
    for i in range(len(list)):
        if i>3:
            break
        vmsg = {}
        mt = list[i].select(".title")[0]
        vtitle = mt.select("a")[0].text.strip()
        if same and len(data)>0 and vtitle!=title:
            break
        if title == vtitle:
            same = True
        vid = mt.select("a")[0].get('href')
        vid = re.findall(r"subject%2F(.+?)%2F",vid)[0]
        type = mt.select('h3 > span')[0].text
        if len(type)>5:
            continue
        diff = mt.select('.subject-cast')[0].text.split(" ")[-1]
        vmsg['id'] = vid
        vmsg['sub_title'] = vtitle
        vmsg['subtype'] = 'movie'
        vmsg['lang'] = 'zh'
        vmsg['diff'] = diff
        data.append(vmsg)

    json['data'] = data
    return json

def main(argv):
    title = "".join(argv).replace('BD','').replace('HD','').replace('：',':')
    title =  baiduformatTi(title)
    list =  doubanlist(title)
    if 'reget' in list:
        list = doubanlist(title)
    data = json.dumps(list, ensure_ascii=False)
    print(data)
if __name__ == '__main__':
    main(sys.argv[1:])