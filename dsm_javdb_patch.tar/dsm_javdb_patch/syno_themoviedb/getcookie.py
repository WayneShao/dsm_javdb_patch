#!/usr/bin/python2
#-*- coding:utf8 -*-
# By sanyle 2018-05-03

import requests

def getweb():
    headers = {"User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko)",
               "Accept": "text/html,application/xhtml+xml,application/xml",
               "Accept-Language": "zh-CN,zh;q=0.9",
               "Upgrade-Insecure-Requests": "1",
               "Referer": "https://www.douban.com/"
               }
    r = requests.get('https://www.douban.com',headers=headers)
    cookie =  {c.name:c.value for c in r.cookies}
    with open('/var/packages/VideoStation/target/plugins/syno_themoviedb/dbcook.txt', 'w') as txt:
        txt.write(str(cookie))
    return cookie

def read():
    try:
        with open('/var/packages/VideoStation/target/plugins/syno_themoviedb/dbcook.txt', 'r') as txt:
            cookie = eval(txt.read())
    except:
        cookie = getweb()
    return cookie

def get(r):
    if r:
        return read()
    else:
        return getweb()