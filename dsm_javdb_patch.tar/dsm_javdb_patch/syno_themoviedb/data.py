#!/usr/bin/python2
#-*- coding:utf8 -*-
# By sanyle 2018-05-03

import requests,sys,os,time
from bs4 import BeautifulSoup
import json
import getcookie
import urllib

reload(sys)
sys.setdefaultencoding('utf8')

headers={"User-Agent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko)",
         "Accept": "text/html,application/xhtml+xml,application/xml",
         "Accept-Language": "zh-CN,zh;q=0.9",
         "Upgrade-Insecure-Requests":"1",
         "Referer": "https://www.douban.com/"
         }

def checkimg(vid,type,cookies):
    url = "https://movie.douban.com/subject/{}/photos?type={}".format(vid,type)
    r = requests.get(url,headers=headers,cookies=cookies).content.decode("utf-8")
    soup = BeautifulSoup(r,'lxml')
    imgs = soup.select(".article > ul > li")
    for i in imgs:
        img = i.select("img")[0]["src"]
        img = img.replace("/m/","/l/").replace(".webp",".jpg")
        if requests.head(img,headers=headers).status_code == 200:
            return img
    return ""

def getbaiducache(url,title):
    wd = urllib.quote(url)
    burl = "http://www.baidu.com/s?wd=" + wd
    r = requests.get(burl,headers=headers).content.decode('utf-8')
    soup = BeautifulSoup(r,'lxml')
    if '没有找到该URL' in soup:
        return ''
    list = soup.select('#content_left > .result')
    for i in list:
        ti = i.select("h3")[0].text.strip().replace(':','：')
        if title in ti and '豆瓣' in ti:
            cacheurl = i.select('a')[-1]['href']
            return cacheurl
    return ''

def gk(info,key):
    try:
        rt = info[key]
        sp = rt.split('/')
        rt = ''
        for i in range(len(sp)):
            if i == len(sp)-1:
                rt = rt + sp[i].strip()
            else:
                rt = rt + sp[i].strip()+'/'

    except:
        rt = ""
    return rt
def checkcode(url):
    img = requests.head(url,headers=headers)
    if img.status_code ==200:
        return True
    else:
        return False

def getdata(vid,title):
    ck = getcookie.get(True)
    cookies = dict(bid=ck['bid'], ll=ck['ll'])
    url = "https://movie.douban.com/subject/{}/".format(vid)
    burl = getbaiducache(url,title)
    if burl:
        try:
            r = requests.get(burl, headers=headers)
            r = r.content.decode('gb2312', 'ignore').encode('utf-8')
            r = r[r.index('<div style="position:relative">'):]
            cache = True
        except:
            r = requests.get(url, headers=headers, cookies=cookies)
            r = r.content.decode('utf-8')
            cache = False
            time.sleep(1)
    else:
        r = requests.get(url,headers=headers,cookies=cookies)
        r = r.content.decode('utf-8')
        cache = False
        time.sleep(1)
    soup = BeautifulSoup(r,'lxml')
    try:
        title = soup.select("#content > h1 > span")[0].text
    except:
        return ''
    info = soup.select('.subjectwrap #info')
    info = str(info[0])
    list = info.split('<br/>')
    info = {}
    for i in list:
        i = i.replace("\n","")
        txt = BeautifulSoup(i,'lxml').text.split(":")
        try:
            info[txt[0]] = txt[1].strip()
        except:
            continue
    rt = {}
    rt["id"] = vid
    rt["title"] = title
    rt["original_title"] = ""
    rt["origin_country"] = gk(info,u"制片国家/地区")
    rt["origin_country"] = ""
    rt["genres"] = gk(info,u"类型").split("/")
    rt["directors"] = [{"name":gk(info,u"导演")}]
    try:
        bianju = gk(info,u"编剧").split("/")
        bjl = []
        for bj in bianju:
            bjl.append({"name":bj})
        rt["writers"] = bjl
    except:
        rt["writers"] = ""
    yyl = []
    try:
        yanyuan = gk(info,u"主演").split("/")
        for yy in yanyuan:
            yyl.append({"name":yy,"profile_path":""})
        rt["actors"] = yyl
    except:
        rt["actors"] = ""
    rt["aka"] = gk(info,u"又名").split("/")
    rt["original_available"] = gk(info,u"上映日期").split("(")[0]
    rt["imdb_id"] = gk(info,u"IMDb链接")
    try:
        summtext = soup.select("#link-report > span")[0].text.replace('\n','').strip()
        if cache:
            summtext = summtext + ' @BD'
        else:
            summtext = summtext + ' @DB'
        rt["summary"] = summtext
    except:
        rt["summary"] =""
    try:
        rt["rating"] = {"average":soup.select(".rating_num")[0].text}
    except:
        rt["rating"] =""
    try:
        rt["rating_people"] = soup.select(".rating_people > span")[0].text
    except:
        rt["rating_people"] =""
    rimg = soup.select('.nbgnbg > img')[0]['src'].replace('s_ratio','l_ratio').replace('.webp','.jpg')
    if checkcode(rimg):
        rt["images"] = {"large":rimg }
    else:
        rt["images"] = {"large":checkimg(vid,"R",cookies)}
    simg = soup.select('.related-pic-bd > li')[1:]
    siu = ''
    for si in simg:
        siu = si.select('a > img')[0]['src'].replace('/sqxs/','/l/').replace('.webp','.jpg')
        if requests.head(siu,headers=headers) == 200:
            break
    rt["backdrop_path"] = siu
    data = json.dumps(rt, ensure_ascii=False)
    return data

def main(argv):

    vid = argv[0]
    if len(vid) ==0:
        return
    title = argv[1:]
    title = ''.join(title)
    data = getdata(vid,title)
    if 'reget' in data:
        data = getdata(vid,title)
    print (data)

if __name__ == '__main__':
    main(sys.argv[1:])